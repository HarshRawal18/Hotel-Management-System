from django.apps import AppConfig


class HotelConfig(AppConfig):
    name = 'hotel'
